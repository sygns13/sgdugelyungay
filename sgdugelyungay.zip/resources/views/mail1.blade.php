<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title>Mail From SGD UGEL YUNGAY</title>
</head>
<body>

Mensaje: 
<p style="text-align:justify;">{!! $msg !!}</p>

<br>
<br>
Atte:<br>
---------------------<br>
<h4>Sistema de Gestión Documental</h4>
<h4>UGEL YUNGAY</h4>
<h4>Mensaje Automático Enviado mediante la plataforma SGD - Ugel Yungay</h4>
</body>
</html>