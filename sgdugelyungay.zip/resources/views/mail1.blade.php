<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title>Mail From SGD UGEL YUNGAY</title>
</head>
<body>

Mensaje: 
<p style="text-align:justify;">{!! $msg !!}</p>

<br>
<br>
Atte:<br>
---------------------<br>
<h4 style="margin: 0px;">Sistema de Registro de Trámites Documentarios</h4>
<h4 style="margin: 0px;">UGEL YUNGAY</h4>
<h4 style="margin: 0px;">Mensaje Automático Enviado mediante la plataforma Web - Ugel Yungay</h4>
</body>
</html>