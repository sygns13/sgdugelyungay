
{{--  <iframe src='{{ asset('menu/index.php/') }}videoLink={{ $videoP->enlace }}&videoTitulo={{ $videoP->titulo }}&presenT={{ $preIni->titulo }}&iduser={{ $iduser }}&estado=inicio' style="width: 100%;border: 0px;"  height="635" >
	
</iframe>--}}

<iframe src="{{ asset('menuUser/index-2.php/') }}?videoLink={{ $videoP->enlace }}&videoTitulo={{ $videoP->titulo }}&presenT={{ $preIni->titulo }}&iduser={{ $iduser }}&estado=indi" style="width: 100%;border: 0px;height: 100%;"  height="100%" >
	
</iframe>