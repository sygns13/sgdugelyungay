{{--  @extends('adminlte::auth.login')
<body onload="redireccionar();">
</body>

<script type="text/javascript">
	function redireccionar(){
  window.location.href = "login";
} 

</script>
--}}

{{  bcrypt('1csjanrer') }}<br>
{{  bcrypt('2csjanreq') }}<br>
{{  bcrypt('3csjanrep') }}<br>
{{  bcrypt('4csjanreo') }}<br>
{{  bcrypt('5csjanren') }}<br>
{{  bcrypt('6csjanrem') }}<br>
{{  bcrypt('7csjanrel') }}<br>
{{  bcrypt('8csjanrek') }}<br>
{{  bcrypt('9csjanrej') }}<br>
{{  bcrypt('10csjanreix') }}<br>
{{  bcrypt('11csjanreh') }}<br>
{{  bcrypt('12csjanreg') }}<br>
{{  bcrypt('13csjanref') }}<br>
{{  bcrypt('14csjanree') }}<br>
{{  bcrypt('15csjanred') }}<br>
{{  bcrypt('16csjanrec') }}<br>
{{  bcrypt('17csjanreb') }}<br>
{{  bcrypt('18csjanrea') }}<br>
{{  bcrypt('19csjanrez') }}<br>
{{  bcrypt('20csjanrey') }}<br>
{{  bcrypt('21csjanreix') }}<br>
{{  bcrypt('22csjanrew') }}<br>
{{  bcrypt('23csjanreiv') }}<br>
{{  bcrypt('24csjanreu') }}<br>
{{  bcrypt('25csjanret') }}<br>
{{  bcrypt('26csjanres') }}<br>
{{  bcrypt('27csjanrer') }}<br>
{{  bcrypt('28csjanreq') }}<br>
{{  bcrypt('29csjanrep') }}<br>
{{  bcrypt('30csjanreo') }}<br>
{{  bcrypt('31csjanren') }}<br>
{{  bcrypt('32csjanrem') }}<br>
{{  bcrypt('33csjanrel') }}<br>
{{  bcrypt('34csjanrek') }}<br>
{{  bcrypt('35csjanrej') }}<br>
{{  bcrypt('36csjanrex') }}<br>
{{  bcrypt('37csjanreh') }}<br>
{{  bcrypt('38csjanreg') }}<br>
{{  bcrypt('39csjanref') }}<br>
{{  bcrypt('40csjanree') }}<br>
{{  bcrypt('41csjanred') }}<br>
{{  bcrypt('42csjanrec') }}<br>
{{  bcrypt('43csjanreb') }}<br>
{{  bcrypt('44csjanrea') }}<br>
{{  bcrypt('45csjanrez') }}<br>
{{  bcrypt('46csjanrey') }}<br>
{{  bcrypt('47csjanrex') }}<br>
{{  bcrypt('48csjanrew') }}<br>
{{  bcrypt('49csjanrev') }}<br>
{{  bcrypt('50csjanreu') }}<br>
{{  bcrypt('51csjanret') }}<br>
{{  bcrypt('52csjanres') }}<br>
{{  bcrypt('53csjanrer') }}<br>
{{  bcrypt('54csjanreq') }}<br>
{{  bcrypt('55csjanrep') }}<br>
{{  bcrypt('56csjanreo') }}<br>
{{  bcrypt('57csjanren') }}<br>
{{  bcrypt('58csjanrem') }}<br>
{{  bcrypt('59csjanrel') }}<br>
{{  bcrypt('60csjanrek') }}<br>
{{  bcrypt('61csjanrej') }}<br>
{{  bcrypt('62csjanrei') }}<br>
{{  bcrypt('63csjanreh') }}<br>
{{  bcrypt('64csjanreg') }}<br>
{{  bcrypt('65csjanref') }}<br>
{{  bcrypt('66csjanree') }}<br>
{{  bcrypt('67csjanred') }}<br>
{{  bcrypt('68csjanrec') }}<br>
{{  bcrypt('69csjanreb') }}<br>
{{  bcrypt('70csjanrea') }}<br>