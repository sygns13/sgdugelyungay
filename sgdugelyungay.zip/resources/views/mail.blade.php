<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title>Mail From SGD UGEL YUNGAY</title>
</head>
<body>

Mensaje: 
<p>{!! $msg !!}</p>

<br>
<br>
Atte:<br>
---------------------<br>
<h4>Administrador REDIES: {{$admin}}</h4>
<h4>Usuario: Administrador</h4>
<h4>Mensaje Enviado mediante la plataforma REDIES Poder Judicial - Distrito Judicial Ancash</h4>
</body>
</html>