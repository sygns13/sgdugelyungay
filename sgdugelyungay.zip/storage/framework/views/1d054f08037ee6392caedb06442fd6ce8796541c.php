<!-- Compiled app javascript -->
<script src="<?php echo e(asset('/js/app.js')); ?>"></script>


<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript"></script>

<script src="<?php echo e(asset('js/mostrarMenu.js')); ?>"  type="text/javascript"></script>

<script src="<?php echo e(asset('js/jquery.prettyPhoto.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"  type="text/javascript"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/select2.full.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/alertify.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/jquery.PrintArea.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/fileinput.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/locales/es.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('iCheck/icheck.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('Ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-colorpicker.js')); ?>"  type="text/javascript"></script>
<script src="<?php echo e(asset('js/axios.js')); ?>"  type="text/javascript"></script>
<?php echo NoCaptcha::renderJs(); ?>