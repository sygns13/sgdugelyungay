<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        <b>Unidad de Gestión Educativa Local  </b>YUNGAY.
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2019 <a href="http://www.hardsystem.org/" target="_blank">Web Master</a>.</strong> 
</footer>
