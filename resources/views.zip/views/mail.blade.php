<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title>CORREO ELECTRÓNICO DESDE LA PLATAFORMA WEB DE REGISTRO DE TRÁMITES - UGEL YUNGAY</title>
</head>
<body>

Mensaje: 
<p>{!! $msg !!}</p>

<br>
<br>
Atte:<br>
---------------------<br>
<h4 style="margin: 0px;">Administrador Plataforma Web de Registro de Trámites - UGEL YUNGAY: {{$admin}}</h4>
<h4 style="margin: 0px;">Usuario: Operador del Sistema</h4>
<h4 style="margin: 0px;">Mensaje Enviado mediante la plataforma Web de Registro de Trámites de la UGEL YUNGAY</h4>
</body>
</html>